import React from 'react'
import Navbar from '../components/Navbar'

const MenuPage = () => {
  return (
    <>
      <Navbar/>
      <div>MenuPage</div>
    </>
  )
}

export default MenuPage