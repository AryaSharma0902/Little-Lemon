import React from 'react'
import Navbar from '../components/Navbar'
const OrderPage = () => {
  return (
    <>
    <Navbar />
    <div>OrderPage</div>
    </>
  )
}

export default OrderPage