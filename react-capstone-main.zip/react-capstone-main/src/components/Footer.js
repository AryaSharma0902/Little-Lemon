import React from 'react'

const Footer = () => {
  return (
    <footer>
        <p>2023 Little Lemon</p>
      </footer>
  )
}

export default Footer